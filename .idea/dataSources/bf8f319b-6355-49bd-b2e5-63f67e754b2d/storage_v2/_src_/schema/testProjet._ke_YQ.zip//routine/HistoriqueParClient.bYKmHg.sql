create
    definer = root@localhost procedure HistoriqueParClient(IN IDClient int)
BEGIN
SELECT C.nom_complet, M.ID_commande, P.montant_total, L.date_livraison, L.statut_livraison
FROM Client C, Commande M, Livraison L, Paiement P
WHERE IDClient = C.ID_client AND C.ID_client = M.ID_client AND L.ID_commande = M.ID_commande;
END;

